

<?php $__env->startSection('javascript'); ?>
<script src="/js/confirm.js"></script>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header d-flex justify-content-between">
        成績編集
        <form id="delete-form" action="<?php echo e(route('destroy')); ?>" method="POST" style="margin:0;">
            <?php echo csrf_field(); ?>
            <input type="hidden" value="<?php echo e($edit_score[0]['id']); ?>" name="score_id">
            <button type="submit">削除</button>
        </form>
    </div>
    
    <!--/storeとパスを指定しているとurlを変更した際に変更が手間なので、route関数を用いておく-->
    <form class="card-body my-card-body" action="<?php echo e(route('update')); ?>" method="POST">
        <!--csrf攻撃の予防としてトークンを生成-->
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <input type="hidden" value="<?php echo e($edit_score[0]['id']); ?>" name="score_id">

            生徒氏名を選択してください<br>
            <select class="form-group" name="student_id" value="<?php echo e($edit_score[0]['student_id']); ?>">
                <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option class="form-group-item" name="student_id" id="<?php echo e($s['id']); ?>" value="<?php echo e($s['id']); ?>">
                        <label class="form-check-label" for="<?php echo e($s['id']); ?>"><?php echo e($s['name']); ?></label>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <br>

            科目を選択してください<br>
            <select class="form-group" name="subject_id">
                <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option class="form-group-item" name="subject_id" id="<?php echo e($s['id']); ?>" value="<?php echo e($edit_score[0]['subject_id']); ?>">
                        <label class="form-check-label" for="<?php echo e($s['id']); ?>"><?php echo e($s['name']); ?></label>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <br>

            点数を入力してください<br>
            <input type="number" min="0" max="100" name="score" value="<?php echo e($edit_score[0]['score']); ?>"><br><br>
            <textarea class="form-control" name="comment" rows="3" placeholder="ここにコメントを入力"><?php echo e($edit_score[0]['comment']); ?></textarea><br>
        </div>

        <!--必須項目チェック(バリデーション)-->
        <?php $__errorArgs = ['score'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="alert alert-danger">点数を入力してください！</div> 
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <button type="submit" class="btn btn-primary">更新</button>
    </form>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\score-helper\resources\views/edit.blade.php ENDPATH**/ ?>